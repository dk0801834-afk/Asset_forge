
=========================================
  100 Minimalist 3D App Icons
  AssetForge B2B Creative Bundle
=========================================

Thank you for your purchase!

Order Number: AF-D310078E
Purchase Date: 2026-09-06 15:00:34 UTC
Bundle: 100 Minimalist 3D App Icons
Number of Assets: 100
File Formats: PNG, BLEND, GLB, FIG

ABOUT THIS BUNDLE
-----------------
A premium collection of 100 hand-crafted minimalist 3D icons rendered in 4K resolution. Perfect for mobile apps, SaaS dashboards, landing pages, and pitch decks. Each icon comes in multiple angles and color variations.

LICENSE
-------
This bundle is licensed for business use under the AssetForge Standard B2B License.
- Unlimited commercial projects
- Perpetual usage rights
- No attribution required
- Cannot resell or redistribute raw assets

SUPPORT
-------
For support, contact support@assetforge.io with your order number.

Build something amazing!
-- The AssetForge Team
